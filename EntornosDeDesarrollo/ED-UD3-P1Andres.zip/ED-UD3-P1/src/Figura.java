public class Figura {

    public String tipo;   // "esfera" o "cilindro"
    public double altura;    // -1 si es esfera
    public double radio;     // 1 a 10

    public Figura() {
        tipo = "";
        altura = -1;
        radio = -1;
    }
    public void setFigura(String ft,double fr, double fa) {

        tipo = ft;

        if (tipo == "esfera") {
            altura = -1;
            radio = fr;
        } else {
            tipo = "cilindro";
            altura =  fa;
            radio =  fr;
        }
    }

    @Override
    public String toString() {
        return "Cuerpo{" +
                "tipo='" + tipo + '\'' +
                ", altura=" + altura +
                ", radio=" + radio +
                '}';
    }
}
