package Ejercicio2;

public class Camion extends Vehiculo {

    @Override
    public void describirVehiculo() {
        System.out.println("Este es un camión, se utiliza para transportar cargas pesadas.");
    }
}

