package Ejercicio2;

public class Motocicleta extends Vehiculo {

    @Override
    public void describirVehiculo() {
        System.out.println("Esta es una motocicleta, es rápida y ocupa poco espacio.");
    }
}

