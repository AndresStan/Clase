package Ejercicio2;
public class Auto extends Vehiculo {

    @Override
    public void describirVehiculo() {
        System.out.println("Este es un auto, tiene cuatro ruedas y es ideal para la ciudad.");
    }
}
