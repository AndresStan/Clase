package Ejercicio2;

public class Vehiculo {

    public void describirVehiculo() {
        System.out.println("Este es un vehículo.");
    }
}