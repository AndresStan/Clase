package Ejercicio3;

public abstract class MetodoPago {

    // Método abstracto
    public abstract void procesarPago(double monto);
}

